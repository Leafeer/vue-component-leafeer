<template>
	<home></home>
</template>

<script>
import Home from "./views/Home";
export default {
	data() {
		return {};
	},
	components: {
		Home
	}
};
</script>

